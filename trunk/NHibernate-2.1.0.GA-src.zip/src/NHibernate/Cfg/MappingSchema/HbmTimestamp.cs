namespace NHibernate.Cfg.MappingSchema
{
	partial class HbmTimestamp : AbstractDecoratable
	{
		protected override HbmMeta[] GetMetadataField()
		{
			return meta;
		}
	}
}