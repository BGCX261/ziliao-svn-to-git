namespace NHibernate.Engine.Query.Sql
{
	/// <summary> Describes a return in a native SQL query. </summary>
	public interface INativeSQLQueryReturn
	{
	}
}
